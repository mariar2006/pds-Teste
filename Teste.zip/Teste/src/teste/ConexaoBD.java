package teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {
	public static Connection getConexaoMySQL() {
		Connection connection = null;
		String driverName = "com.mysql.cj.jdbc.Driver";
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("O driver especificado não foi encontrado");
		}
		//Nome do servidor
		String serverName = "localhost";
		
		//Nome do banco de dados
		String mydatebase = "teste";
		
		//URL de conexão
		//String url = "jdbc:mysql://localhost:3306/teste";
		String url = "jdbc:mysql://" + serverName + "/" + mydatebase;
		
		String username = "root";
		
		String password = "aluno";
		
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Não foi possivel conectar ao banco de dados");
		}
		
		
		
		return connection;
	}

}
